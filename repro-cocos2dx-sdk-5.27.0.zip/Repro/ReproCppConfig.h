//
//  ReproCppConfig.h
//

#ifndef __REPRO_CPP_CONFIG_H__
#define __REPRO_CPP_CONFIG_H__

#if COCOS2D_VERSION >= 0x00030000
#define CLASS_NAME_REPRO_CLIENT_BRIDGE  "com.your.PackageName.ReproBridge"
#else
#define CLASS_NAME_REPRO_CLIENT_BRIDGE  "com/your/PackageName/ReproBridge"
#endif

#define JNI_REPRO_CLIENT_BRIDGE         com_your_PackageName_ReproBridge

#endif
