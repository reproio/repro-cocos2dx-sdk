//
//  ReproCpp.h
//
//  Created by jollyjoester_pro on 10/31/14.
//  Copyright (c) 2014 Repro Inc. All rights reserved.
//

#ifndef __REPRO_CPP_H__
#define __REPRO_CPP_H__

#include <string>
#include <map>
#include <vector>
#include <ctime>
#include <functional>
#include "ReproEventProperties.h"
#include "ReproCppConfig.h"

#if defined(__ANDROID__)

#include <jni.h>
#define NativeNewsFeedEntry     jobject
#define NativeRemoteConfigValue jobject
#define NativeRemoteConfig      jobject

namespace repro {
    JNIEnv* getEnv();
}

#elif defined(__OBJC__)

#import <Repro/Repro.h>
@class RPRNewsFeedEntry;
#define NativeNewsFeedEntry     RPRNewsFeedEntry*
#define NativeRemoteConfigValue RPRRemoteConfigValue*
#define NativeRemoteConfig      RPRRemoteConfig*

#else

#define NativeNewsFeedEntry     void*
#define NativeRemoteConfigValue void*
#define NativeRemoteConfig      void*

#endif


#define COCOS_2DX_BRIDGE_VERSION "5.27.0"


class ReproCpp {

public:

    enum class CampaignType : uint64_t {
        // The same values in RPRCampaignType
        Unknown = 0,

        PushNotification = (1 << 0),
        InAppMessage     = (1 << 1),
        WebMessage       = (1 << 2),
        All              = (1 << 3),
    };

    class NewsFeedEntry {

    private:
        NativeNewsFeedEntry newsFeedEntry;

    public:
        NewsFeedEntry(NativeNewsFeedEntry newsFeedEntry);

        NativeNewsFeedEntry getNativeNewsFeedEntry();

        uint64_t getID();
        const char * getDeviceID();
        const char * getTitle();
        const char * getSummary();
        const char * getBody();
        ReproCpp::CampaignType getCampaignType();
        const char * getLinkUrl();
        const char * getLinkUrlString();
        const char * getImageUrl();
        const char * getImageUrlString();
        time_t getDeliveredAt();
        bool getShown();
        bool getRead();
        void setShown(bool value);
        void setRead(bool value);
    };

    class RemoteConfigValue {

    private:
        NativeRemoteConfigValue remoteConfigValue;

    public:
        RemoteConfigValue(NativeRemoteConfigValue remoteConfigValue);

        const char* getStringValue();
    };
    class RemoteConfig {

    public:

        enum FetchStatus : int {
            FetchStatusSuccess = 0,
            FetchStatusTimeoutReached,
            FetchStatusAlreadyFetched
        };

    private:
        NativeRemoteConfig remoteConfig;
        std::function<void(FetchStatus status)> completion;

    public:
        RemoteConfig(NativeRemoteConfig remoteConfig);

        void fetch(double timeout, std::function<void(FetchStatus status)> completion);
        bool activateFetched();
        bool setDefaultsFromMap(std::map<std::string, std::string> values);
        bool setDefaultsFromJsonFile(const char *filePath);
        bool setDefaultsFromJsonString(const char *jsonString);

        RemoteConfigValue get(const char *key);
        RemoteConfigValue getLocalDefaultValue(const char *key);
        std::map<std::string, RemoteConfigValue*> getAllValues();
        std::map<std::string, RemoteConfigValue*> getAllValuesWithPrefix(const char *prefix);

        void forceReset();
    };

    enum UserProfileGender : int {
        UserProfileGenderOther = 0,
        UserProfileGenderMale,
        UserProfileGenderFemale
    };

    enum UserProfilePrefecture : int {
        UserProfilePrefectureHokkaido = 1,
        UserProfilePrefectureAomori,
        UserProfilePrefectureIwate,
        UserProfilePrefectureMiyagi,
        UserProfilePrefectureAkita,
        UserProfilePrefectureYamagata,
        UserProfilePrefectureFukushima,
        UserProfilePrefectureIbaraki,
        UserProfilePrefectureTochigi,
        UserProfilePrefectureGunma,
        UserProfilePrefectureSaitama,
        UserProfilePrefectureChiba,
        UserProfilePrefectureTokyo,
        UserProfilePrefectureKanagawa,
        UserProfilePrefectureNiigata,
        UserProfilePrefectureToyama,
        UserProfilePrefectureIshikawa,
        UserProfilePrefectureFukui,
        UserProfilePrefectureYamanashi,
        UserProfilePrefectureNagano,
        UserProfilePrefectureGifu,
        UserProfilePrefectureShizuoka,
        UserProfilePrefectureAichi,
        UserProfilePrefectureMie,
        UserProfilePrefectureShiga,
        UserProfilePrefectureKyoto,
        UserProfilePrefectureOsaka,
        UserProfilePrefectureHyogo,
        UserProfilePrefectureNara,
        UserProfilePrefectureWakayama,
        UserProfilePrefectureTottori,
        UserProfilePrefectureShimane,
        UserProfilePrefectureOkayama,
        UserProfilePrefectureHiroshima,
        UserProfilePrefectureYamaguchi,
        UserProfilePrefectureTokushima,
        UserProfilePrefectureKagawa,
        UserProfilePrefectureEhime,
        UserProfilePrefectureKochi,
        UserProfilePrefectureFukuoka,
        UserProfilePrefectureSaga,
        UserProfilePrefectureNagasaki,
        UserProfilePrefectureKumamoto,
        UserProfilePrefectureOita,
        UserProfilePrefectureMiyazaki,
        UserProfilePrefectureKagoshima,
        UserProfilePrefectureOkinawa
    };

    // Setup
    static void setup(const char* token);

    // OptIn / OptOut
    static void optIn(bool endUserOptedIn);

    // Log Level
    static void setLogLevel(const char* logLevel);

    // User Profile
    static void setUserID(const char* userId);
    static const char* getUserID();
    static const char* getDeviceID();
    static void setStringUserProfile(const char* key, const char* value);
    static void setIntUserProfile(const char* key, int value);
    static void setDoubleUserProfile(const char* key, double value);
    static void setDateUserProfile(const char* key, std::time_t value);
    static void setUserGender(enum UserProfileGender gender);
    static void setUserEmailAddress(const char* value);
    static void setUserResidencePrefecture(enum UserProfilePrefecture prefecture);
    static void setUserDateOfBirth(int year, int month, int day);
    static void setUserAge(int age);

    // New User Profile Methods
    static void onlySetIfAbsentStringUserProfile(const char* key, const char* value);
    static void onlySetIfAbsentIntUserProfile(const char* key, int value);
    static void onlySetIfAbsentDoubleUserProfile(const char* key, double value);
    static void onlySetIfAbsentDateUserProfile(const char* key, std::time_t value);
    static void incrementIntUserProfileBy(const char* key, int value);
    static void decrementIntUserProfileBy(const char* key, int value);
    static void incrementDoubleUserProfileBy(const char* key, double value);
    static void decrementDoubleUserProfileBy(const char* key, double value);
    static void onlySetIfAbsentUserGender(enum UserProfileGender gender);
    static void onlySetIfAbsentUserEmailAddress(const char* value);
    static void onlySetIfAbsentUserResidencePrefecture(enum UserProfilePrefecture prefecture);
    static void onlySetIfAbsentUserDateOfBirth(int year, int month, int day);
    static void onlySetIfAbsentUserAge(int age);
    static void incrementUserAgeBy(int value);
    static void decrementUserAgeBy(int value);
    static void deleteUserProfile(const char* key);
    static void deleteUserGender();
    static void deleteUserEmailAddress();
    static void deleteUserResidencePrefecture();
    static void deleteUserDateOfBirth();
    static void deleteUserAge();

    // Standard Event Tracking
    static void trackViewContent(const char* contentId, repro::ViewContentProperties* properties);
    static void trackSearch(repro::SearchProperties* properties);
    static void trackAddToCart(const char* contentId, repro::AddToCartProperties* properties);
    static void trackAddToWishlist(repro::AddToWishlistProperties* properties);
    static void trackInitiateCheckout(repro::InitiateCheckoutProperties* properties);
    static void trackAddPaymentInfo(repro::AddPaymentInfoProperties* properties);
    static void trackPurchase(const char* contentId, double value, const char* currency, repro::PurchaseProperties* properties);
    static void trackShare(repro::ShareProperties* properties);
    static void trackLead(repro::LeadProperties* properties);
    static void trackCompleteRegistration(repro::CompleteRegistrationProperties* properties);

    // Event Tracking
    static void track(const char*eventName);
    static void trackWithProperties(const char* eventName, const char* jsonDictionary);

    // In App Message
    static void disableInAppMessagesOnForegroundTransition();
    static void enableInAppMessagesOnForegroundTransition();

    // Push Notification
    static void setPushRegistrationID(const char* registrationID);

    // SilverEgg
    static void setSilverEggCookie(const char* cookie);
    static void setSilverEggProdKey(const char* key);

    // LINE Integration
    static void linkLineID(const char* lineUserId, const char* lineChannelId);
    static void unlinkLineID(const char* lineUserId, const char* lineChannelId);

    // Email Channel Integration
    static void subscribeEmailChannel(long channelId);
    static void unsubscribeEmailChannel(long channelId);

    // Event Callbacks
    static void addOpenUrlFilterRegEx(const char* filterRegEx);
    static void setOpenUrlCallback(std::function<void(const char* url)> callback);

    // NewsFeed
    static std::vector<ReproCpp::NewsFeedEntry> getNewsFeeds(uint64_t limit, bool *error);
    static std::vector<ReproCpp::NewsFeedEntry> getNewsFeeds(uint64_t limit, ReproCpp::CampaignType campaignType, bool *error);
    static std::vector<ReproCpp::NewsFeedEntry> getNewsFeeds(uint64_t limit, uint64_t offsetID, bool *error);
    static std::vector<ReproCpp::NewsFeedEntry> getNewsFeeds(uint64_t limit, uint64_t offsetID, ReproCpp::CampaignType campaignType, bool *error);
    static bool updateNewsFeeds(std::vector<ReproCpp::NewsFeedEntry> newsFeeds, bool *error);

    // RemoteConfig
    static ReproCpp::RemoteConfig getRemoteConfig();
};

bool operator==(ReproCpp::CampaignType& L, ReproCpp::CampaignType& R);

#if defined(__ANDROID__)
extern "C" {

    // To ensure expand className, it needs two steps.
    #define DECL_JNI_CALLBACK(className, methodName, arg)  DECL_JNI_CALLBACK_2(className, methodName, arg)
    #define DECL_JNI_CALLBACK_2(className, methodName, arg)  JNIEXPORT void JNICALL Java_ ## className ## _ ## methodName (JNIEnv* env, jobject thiz, arg)

    DECL_JNI_CALLBACK(JNI_REPRO_CLIENT_BRIDGE, nativeListenerHandler, jobject status);

};
#endif


#endif
