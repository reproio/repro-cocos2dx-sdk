//
//  ReproCppConfig.h
//

#ifndef __REPRO_CPP_CONFIG_H__
#define __REPRO_CPP_CONFIG_H__

#define CLASS_NAME_REPRO_CLIENT_BRIDGE  "com.your.PackageName.ReproBridge"
#define JNI_REPRO_CLIENT_BRIDGE         com_your_PackageName_ReproBridge

#endif
