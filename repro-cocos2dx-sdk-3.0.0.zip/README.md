# repro-cocos2dx-sdk

This sdk provides the ability to use [Repro](https://repro.io/)

## Supported Platforms

- iOS
- Android

## Get Started

- [EN](http://docs.repro.io/en/dev/sdk/getstarted/cocos2d-x.html)
- [JA](http://docs.repro.io/ja/dev/sdk/getstarted/cocos2d-x.html)

## Documentation

Read [the documentation](http://docs.repro.io/) for further information

## Releases

- [EN](http://docs.repro.io/en/releases/sdk/cocos2d-x/releases.html)
- [JA](http://docs.repro.io/ja/releases/sdk/cocos2d-x/releases.html)

## Author

Repro, Inc.

## License

(c) 2017 Repro Inc.