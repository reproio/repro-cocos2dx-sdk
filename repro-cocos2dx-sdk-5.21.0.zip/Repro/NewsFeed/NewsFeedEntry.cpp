#include <android/log.h>
#include "platform/android/jni/JniHelper.h"
#include "ReproConverterAndroid.h"
#include "ReproCpp.h"

ReproCpp::NewsFeedEntry::NewsFeedEntry(NativeNewsFeedEntry newsFeedEntry)
{
    this->newsFeedEntry = newsFeedEntry;
}

NativeNewsFeedEntry ReproCpp::NewsFeedEntry::getNativeNewsFeedEntry()
{
    return this->newsFeedEntry;
}

static jclass getNewsFeedEntryClass(JNIEnv *env)
{
    return env->FindClass("io/repro/android/newsfeed/NewsFeedEntry");
}

uint64_t ReproCpp::NewsFeedEntry::getID()
{
    JNIEnv *env = cocos2d::JniHelper::getEnv();
    if (!env) {
        return 0;
    }
    jclass classNewsFeedEntry = getNewsFeedEntryClass(env);
    jfieldID fieldID = env->GetFieldID(classNewsFeedEntry, "id", "J");
    jlong jID = env->GetLongField(this->newsFeedEntry, fieldID);

    env->DeleteLocalRef(classNewsFeedEntry);
    return (uint64_t)jID;
}

const char * ReproCpp::NewsFeedEntry::getDeviceID()
{
    JNIEnv *env = cocos2d::JniHelper::getEnv();
    if (!env) {
        return nullptr;
    }
    jclass classNewsFeedEntry = getNewsFeedEntryClass(env);
    jfieldID fieldID = env->GetFieldID(classNewsFeedEntry, "deviceID", "Ljava/lang/String;");
    jstring stringDeviceID = (jstring)env->GetObjectField(this->newsFeedEntry, fieldID);
    const char *deviceId = env->GetStringUTFChars(stringDeviceID, NULL);

    env->DeleteLocalRef(stringDeviceID);
    env->DeleteLocalRef(classNewsFeedEntry);
    return deviceId;
}

const char * ReproCpp::NewsFeedEntry::getTitle()
{
    JNIEnv *env = cocos2d::JniHelper::getEnv();
    if (!env) {
        return nullptr;
    }
    jclass classNewsFeedEntry = getNewsFeedEntryClass(env);
    jfieldID fieldID = env->GetFieldID(classNewsFeedEntry, "title", "Ljava/lang/String;");
    jstring stringTitle = (jstring)env->GetObjectField(this->newsFeedEntry, fieldID);
    const char *title = env->GetStringUTFChars(stringTitle, NULL);

    env->DeleteLocalRef(stringTitle);
    env->DeleteLocalRef(classNewsFeedEntry);
    return title;
}

const char * ReproCpp::NewsFeedEntry::getSummary()
{
    JNIEnv *env = cocos2d::JniHelper::getEnv();
    if (!env) {
        return nullptr;
    }
    jclass classNewsFeedEntry = getNewsFeedEntryClass(env);
    jfieldID fieldID = env->GetFieldID(classNewsFeedEntry, "summary", "Ljava/lang/String;");
    jstring stringSummary = (jstring)env->GetObjectField(this->newsFeedEntry, fieldID);
    const char *summary = env->GetStringUTFChars(stringSummary, NULL);

    env->DeleteLocalRef(stringSummary);
    env->DeleteLocalRef(classNewsFeedEntry);
    return summary;
}

const char * ReproCpp::NewsFeedEntry::getBody()
{
    JNIEnv *env = cocos2d::JniHelper::getEnv();
    if (!env) {
        return nullptr;
    }
    jclass classNewsFeedEntry = getNewsFeedEntryClass(env);
    jfieldID fieldID = env->GetFieldID(classNewsFeedEntry, "body", "Ljava/lang/String;");
    jstring stringBody = (jstring)env->GetObjectField(this->newsFeedEntry, fieldID);
    const char *body = env->GetStringUTFChars(stringBody, NULL);

    env->DeleteLocalRef(stringBody);
    env->DeleteLocalRef(classNewsFeedEntry);
    return body;
}

ReproCpp::CampaignType ReproCpp::NewsFeedEntry::getCampaignType()
{
    JNIEnv *env = cocos2d::JniHelper::getEnv();
    if (!env) {
        return ReproCpp::CampaignType::Unknown;
    }
    jclass classNewsFeedEntry = getNewsFeedEntryClass(env);
    jfieldID fieldID = env->GetFieldID(classNewsFeedEntry, "campaignType", "Lio/repro/android/newsfeed/NewsFeedCampaignType;");
    jobject campaignType = env->GetObjectField(this->newsFeedEntry, fieldID);

    jclass classNewsFeedCampaignType = env->FindClass("io/repro/android/newsfeed/NewsFeedCampaignType");
    jmethodID methodToString = env->GetMethodID(classNewsFeedCampaignType, "toString", "()Ljava/lang/String;");
    jstring stringCampaignType = (jstring)env->CallObjectMethod(campaignType, methodToString);

    const char *cType = env->GetStringUTFChars(stringCampaignType, NULL);
    std::string type = std::string(cType);
    env->ReleaseStringUTFChars(stringCampaignType, cType);

    env->DeleteLocalRef(campaignType);
    env->DeleteLocalRef(stringCampaignType);
    env->DeleteLocalRef(classNewsFeedCampaignType);
    env->DeleteLocalRef(classNewsFeedEntry);

    if (type == std::string("push_notification")) {
        return ReproCpp::CampaignType::PushNotification;
    }
    if (type == std::string("in_app_message")) {
        return ReproCpp::CampaignType::InAppMessage;
    }
    if (type == std::string("web_message")) {
        return ReproCpp::CampaignType::WebMessage;
    }

    return ReproCpp::CampaignType::Unknown;
}

const char * ReproCpp::NewsFeedEntry::getLinkUrl()
{
    JNIEnv *env = cocos2d::JniHelper::getEnv();
    if (!env) {
        return nullptr;
    }
    jclass classNewsFeedEntry = getNewsFeedEntryClass(env);
    jfieldID fieldID = env->GetFieldID(classNewsFeedEntry, "linkUrl", "Landroid/net/Uri;");
    jobject linkUrl = env->GetObjectField(this->newsFeedEntry, fieldID);

    jclass classUrl = env->FindClass("android/net/Uri");
    jmethodID methodToString = env->GetMethodID(classUrl, "toString", "()Ljava/lang/String;");
    jstring stringLinkUrl = (jstring)env->CallObjectMethod(linkUrl, methodToString);

    const char *url = env->GetStringUTFChars(stringLinkUrl, NULL);

    env->DeleteLocalRef(linkUrl);
    env->DeleteLocalRef(stringLinkUrl);
    env->DeleteLocalRef(classUrl);
    env->DeleteLocalRef(classNewsFeedEntry);
    return url;
}

const char * ReproCpp::NewsFeedEntry::getLinkUrlString()
{
    JNIEnv *env = cocos2d::JniHelper::getEnv();
    if (!env) {
        return nullptr;
    }
    jclass classNewsFeedEntry = getNewsFeedEntryClass(env);
    jfieldID fieldID = env->GetFieldID(classNewsFeedEntry, "linkUrlString", "Ljava/lang/String;");
    jstring tempLinkUrlString = (jstring)env->GetObjectField(this->newsFeedEntry, fieldID);
    const char *linkUrlString = env->GetStringUTFChars(tempLinkUrlString, NULL);

    env->DeleteLocalRef(tempLinkUrlString);
    env->DeleteLocalRef(classNewsFeedEntry);
    return linkUrlString;
}

const char * ReproCpp::NewsFeedEntry::getImageUrl()
{
    JNIEnv *env = cocos2d::JniHelper::getEnv();
    if (!env) {
        return nullptr;
    }
    jclass classNewsFeedEntry = getNewsFeedEntryClass(env);
    jfieldID fieldID = env->GetFieldID(classNewsFeedEntry, "imageUrl", "Landroid/net/Uri;");
    jobject imageUrl = env->GetObjectField(this->newsFeedEntry, fieldID);

    jclass classUrl = env->FindClass("android/net/Uri");
    jmethodID methodToString = env->GetMethodID(classUrl, "toString", "()Ljava/lang/String;");
    jstring stringImageUrl = (jstring)env->CallObjectMethod(imageUrl, methodToString);

    const char *url = env->GetStringUTFChars(stringImageUrl, NULL);

    env->DeleteLocalRef(imageUrl);
    env->DeleteLocalRef(stringImageUrl);
    env->DeleteLocalRef(classUrl);
    env->DeleteLocalRef(classNewsFeedEntry);
    return url;
}

const char * ReproCpp::NewsFeedEntry::getImageUrlString()
{
    JNIEnv *env = cocos2d::JniHelper::getEnv();
    if (!env) {
        return nullptr;
    }
    jclass classNewsFeedEntry = getNewsFeedEntryClass(env);
    jfieldID fieldID = env->GetFieldID(classNewsFeedEntry, "imageUrlString", "Ljava/lang/String;");
    jstring tempImageUrlString = (jstring)env->GetObjectField(this->newsFeedEntry, fieldID);
    const char *imageUrlString = env->GetStringUTFChars(tempImageUrlString, NULL);

    env->DeleteLocalRef(tempImageUrlString);
    env->DeleteLocalRef(classNewsFeedEntry);
    return imageUrlString;
}

time_t ReproCpp::NewsFeedEntry::getDeliveredAt()
{
    JNIEnv *env = cocos2d::JniHelper::getEnv();
    if (!env) {
        return 0;
    }
    jclass classNewsFeedEntry = getNewsFeedEntryClass(env);
    jfieldID fieldID = env->GetFieldID(classNewsFeedEntry, "deliveredAt", "Ljava/util/Date;");
    jobject deliveredAt = env->GetObjectField(this->newsFeedEntry, fieldID);

	jclass classDate = env->FindClass("java/util/Date");
	jmethodID methodGetTime = env->GetMethodID(classDate, "getTime", "()J");
    jlong jTime = env->CallLongMethod(deliveredAt, methodGetTime);

    env->DeleteLocalRef(deliveredAt);
    env->DeleteLocalRef(classDate);
    env->DeleteLocalRef(classNewsFeedEntry);
    return (time_t)(jTime / 1000);
}

bool ReproCpp::NewsFeedEntry::getShown()
{
    JNIEnv *env = cocos2d::JniHelper::getEnv();
    if (!env) {
        return false;
    }
    jclass classNewsFeedEntry = getNewsFeedEntryClass(env);
    jfieldID fieldID = env->GetFieldID(classNewsFeedEntry, "shown", "Z");
    jboolean shown = env->GetBooleanField(this->newsFeedEntry, fieldID);

    env->DeleteLocalRef(classNewsFeedEntry);
    return (bool)shown;
}

bool ReproCpp::NewsFeedEntry::getRead()
{
    JNIEnv *env = cocos2d::JniHelper::getEnv();
    if (!env) {
        return false;
    }
    jclass classNewsFeedEntry = getNewsFeedEntryClass(env);
    jfieldID fieldID = env->GetFieldID(classNewsFeedEntry, "read", "Z");
    jboolean read = env->GetBooleanField(this->newsFeedEntry, fieldID);

    env->DeleteLocalRef(classNewsFeedEntry);
    return (bool)read;
}

void ReproCpp::NewsFeedEntry::setShown(bool value)
{
    JNIEnv *env = cocos2d::JniHelper::getEnv();
    if (!env) {
        return;
    }

    jclass classNewsFeedEntry = getNewsFeedEntryClass(env);
    jfieldID fieldID = env->GetFieldID(classNewsFeedEntry, "shown", "Z");
    env->SetBooleanField(this->newsFeedEntry, fieldID, (jboolean)value);

    env->DeleteLocalRef(classNewsFeedEntry);
}

void ReproCpp::NewsFeedEntry::setRead(bool value)
{
    JNIEnv *env = cocos2d::JniHelper::getEnv();
    if (!env) {
        return;
    }

    jclass classNewsFeedEntry = getNewsFeedEntryClass(env);
    jfieldID fieldID = env->GetFieldID(classNewsFeedEntry, "read", "Z");
    env->SetBooleanField(this->newsFeedEntry, fieldID, (jboolean)value);

    env->DeleteLocalRef(classNewsFeedEntry);
}
