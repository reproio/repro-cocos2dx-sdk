//
//  Repro iOS SDK
//
//  Copyright (c) 2014 Repro Inc. All rights reserved.
//

typedef NS_ENUM(NSInteger, RPRUserProfileGender) {
    RPRUserProfileGenderOther = 0,
    RPRUserProfileGenderMale,
    RPRUserProfileGenderFemale
};
