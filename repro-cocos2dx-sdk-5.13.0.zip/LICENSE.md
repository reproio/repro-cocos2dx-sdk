----------------------------------------------------------------

This product includes 'RSSwizzle' (https://github.com/rabovik/RSSwizzle), which is released under the following license(s):
    MIT <http://opensource.org/licenses/mit-license.html>

----------------------------------------------------------------

This product includes a part of 'Mixpanel iOS SDK' (https://github.com/mixpanel/mixpanel-iphone), which is released under the following license(s):
    Apatch 2 <http://opensource.org/licenses/Apache-2.0>

----------------------------------------------------------------

This product includes 'Grafika' (https://github.com/google/grafika), which is released under the following license(s):
    Apatch 2 <http://opensource.org/licenses/Apache-2.0>

----------------------------------------------------------------

This product includes a part of 'Mixpanel Android SDK' (https://github.com/mixpanel/mixpanel-android), which is released under the following license(s):
    Apatch 2 <http://opensource.org/licenses/Apache-2.0>

----------------------------------------------------------------

All other components of this product are: Copyright (c) 2017 Repro, Inc. All rights reserved.
